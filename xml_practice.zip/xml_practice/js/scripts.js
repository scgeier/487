$(document).ready(function(){
  console.log('DOM loaded');


});
