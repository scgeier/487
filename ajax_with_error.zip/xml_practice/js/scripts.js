$(function(){
  console.log('DOM loaded');

  var url ='practice.xml';
  var data;
  var html = '';

  $.ajax({
    method:'GET',
    url: url,
    data: data,
    dataType:'xml',
    async:true,
    success:function(data){
      console.log(data);
    },
    error:function(msg){/*This throws an error message if the AJAX request was unsuccessful.
                          Try changing something to intentionally break it and
                          trigger the error message (e.g., add a typo in the url above)*/
      alert('Error! Data was not loaded');
    },
    complete:function(){//Add a callback function that will fire no matter what.
                        //This tests whether the $.ajax request was even made in the first place.
      alert('AJAX request complete');
    }
  });

});
