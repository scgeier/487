$(document).ready(function(){
  console.log('scripts loaded');

});
